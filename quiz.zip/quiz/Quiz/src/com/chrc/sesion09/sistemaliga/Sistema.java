/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chrc.sesion09.sistemaliga;

import com.chrc.sesion09.Futbol.Jugador;
import com.chrc.sesion09.Futbol.Persona;
import com.chrc.sesion09.Futbol.TipoPersona;
import com.chrc.sesion09.Futbol.Equipo;
import com.chrc.sesion09.Futbol.Liga;
import java.util.Scanner;

/**
 *
 * @author campusLive Server
 */
public class Sistema {

  private Equipo liga;
  Scanner input = new Scanner(System.in);

  public Sistema() {
    input = new Scanner(System.in);
  }

  public void ejecutar() {
    char opcion;

    do {
      opcion = menuPrincipal();
      if (ejecutarOpcion(opcion) == false) {
        System.out.println("\n\n*** Fin ejecución del programa. ***\n");
        break;
      }
    } while (true);
  }

  private char menuPrincipal() {
    char op = '\0';
    //input = new Scanner(System.in);

    do {

      System.out.println("**********");
      System.out.println("  MENU");
      System.out.println("**********\n");

      System.out.print("""
                             1. Crear Equipo
                             2. Crear Jugador
                             3. Crear Ligas
                             4. Informes
                             5. Salir

                             Eliga una opci\u00f3n [1, 5]:  """);

      String entrada = input.nextLine().trim();
      if (entrada.isEmpty() || entrada.length() > 1) {
        System.out.println("Opcion vacía; es inválida. Es de 1 a 5");
        System.out.print("Presione cualquier tecla para continuar...");
        input.nextLine();
        continue;
      }

      op = entrada.charAt(0);
      if (op < '1' || op > '5') {
        System.out.println("Opcion inválida. Es de 1 a 5");
        System.out.print("Presione cualquier tecla para continuar...");
        input.nextLine();
        continue;
      }

      break;

    } while (true);

    return op;
  }

  private boolean ejecutarOpcion(char opcion) {
    switch (opcion) {
      case '1':
        crearliga();
        mostrarMensaje("La liga fue creada con Exito.");
        break;
      case '2':
        crearMiembroliga();
        break;
      case '3':
        crearLigas();
        break;
      case '4':
          break;
      case '5':
        return false;
    }

    return true;
  }

  private void crearliga() {
    if (liga == null) {
      liga = new Equipo();
    }
  }

  private void mostrarMensaje(String msg) {
    try {
      System.out.println("\n--> " + msg);
      System.out.println("Presione cualquier tecla para continuar...");
      if (input.hasNextLine()) {
        input.nextLine();
      }
    } catch (Exception ex) {
      System.err.println("**> Ha ocurrido un error. " + ex.getMessage());
    }
  }

  private void crearMiembroliga() {
    if (liga == null) {
      mostrarMensaje("La liga no existe. Crea primero una liga y luego los miembros de esta.");
      return;
    }

    char op = '\0';

    do {
      // Scanner input = new Scanner(System.in);
      System.out.println("**********");
      System.out.println("  2. Crear Miembros de la liga");
      System.out.println("**********\n");

      System.out.print("""
                             1. Crear JUGADOR
                             2. Crear Profesor
                             3. Crear Administrativo
                             4. Salir

                             Eliga una opci\u00f3n [1, 4]:  """);

      String entrada = input.nextLine().trim();
      if (entrada.isEmpty() || entrada.length() > 1) {
        System.out.println("Opcion inválida. Es de 1 a 4");
        System.out.print("Presione cualquier tecla para continuar...");
        input.nextLine();
        continue;
      }

      op = entrada.charAt(0);
      if (op < '1' || op > '4') {
        System.out.println("Opcion inválida. Es de 1 a 4");
        System.out.print("Presione cualquier tecla para continuar...");
        input.nextLine();
        continue;
      }

      break;

    } while (true);

    switch (op) {
      case '1':
        crearMiembroLiga(TipoPersona.Jugador);
        break;
    }
  }

  private void crearMiembroLiga(TipoPersona tipoPersona) {
    System.out.println("\n\n\nCREAR " + tipoPersona.name());

    String nombre = "", apellido = "";
    

    try {
      System.out.print("Nombre: ");
      nombre = input.nextLine();

      System.out.print("Apellido: ");
      apellido = input.nextLine();
        break;
      } while (true);
    } catch (Exception ex) {
      mostrarMensaje("Ocurrio un error." + ex.getMessage());
    }

    Persona p = null;
    switch (tipoPersona) {
      case Jugador:
        p = new Jugador
        (nombre, apellido);
        break;
     
     
    }

    liga.setPersona(p);

    mostrarMensaje("Listado de personas:\n" + liga.getPersonas());
  }

  private void crearLigas() {
    if (liga == null) {
      mostrarMensaje("La liga no existe. Crea primero una liga y luego los miembros de esta.");
      return;
    }

    char op = '\0';

    do {
      // Scanner input = new Scanner(System.in);
      System.out.println("***********************");
      System.out.println("  3. Crear Ligas");
      System.out.println("************************\n");

      System.out.print("""
                             1. Crear Liga
                             2. Agregar Miembros liga a la Liga
                             3. Salir

                             Eliga una opci\u00f3n [1, 3]:  """);

      String entrada = input.nextLine().trim();
      if (entrada.isEmpty() || entrada.length() > 1) {
        System.out.println("Opcion inválida. Es de 1 a 3");
        System.out.print("Presione cualquier tecla para continuar...");
        input.nextLine();
        continue;
      }

      op = entrada.charAt(0);
      if (op < '1' || op > '3') {
        System.out.println("Opcion inválida. Es de 1 a 3");
        System.out.print("Presione cualquier tecla para continuar...");
        input.nextLine();
        continue;
      }

      break;

    } while (true);

    switch (op) {
      case '1':
        crearLiga();
        break;
      case '2':
        agregrarMiembroLiga();
        break;
    }

  }

  private void crearLiga() {
    System.out.println("***********************");
    System.out.println("  3. Crear Liga  *");
    System.out.println("************************\n");

    String nomLiga = "", descLiga = "";
    do {
      try {
        System.out.print("Nombre de la Liga? ");
        nomLiga = input.nextLine().trim();
        if (nomLiga.isBlank() || nomLiga.length() == 0) {
          mostrarMensaje("Error. Nombre de la Liga inválido");
          continue;
        }

        System.out.print("Decripcion de la Liga? ");
        descLiga = input.nextLine().trim();
        if (descLiga.isBlank() || descLiga.length() == 0) {
          mostrarMensaje("Error. Decripcion de la Liga inválido");
          continue;
        }


      } catch (Exception ex) {
        mostrarMensaje("Error al pedir nombre y descripcion.");
        continue;
      }

      break;

    } while (true);

    // crear la Liga
    Liga activity = new Liga(nomLiga, descLiga);

    // agregar la Liga a la liga
    liga.setLiga(activity);
    
    
  }

  private void agregrarMiembroLiga() {
    return;
  }

    
}

class TestSistema {
  public static void main(String[] args) {
    Sistema liga = new Sistema();

   liga.ejecutar();
  }
}
