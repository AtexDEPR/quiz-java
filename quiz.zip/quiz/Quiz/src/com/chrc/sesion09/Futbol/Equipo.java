/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chrc.sesion09.Futbol;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author campusLive Server
 */
public class Equipo {
    private Map<Integer, Persona> personas;
    private List<Liga> ligas;

    public Equipo() {
        personas = new HashMap<>();
        ligas = new ArrayList<>();
    }
    

    public Map<Integer, Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(Map<Integer, Persona> personas) {
        this.personas = personas;
    }
    
    public Persona getPersona(int codigo) {
        return personas.get(codigo);
    }

    public void setPersona(Persona persona) {
        this.personas.put(persona.getCodigo(), persona);
    }

    

    public List<Liga> getLigas() {
        return ligas;
    }

    public void setLiga(Liga liga) {
        this.ligas.add(liga);
    }    
    
}
