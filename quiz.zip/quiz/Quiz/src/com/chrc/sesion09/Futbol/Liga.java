/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chrc.sesion09.Futbol;

import java.util.Map;

/**
 *
 * @author campusLive Server
 */
public class Liga {

  private String nombre;
  private String descripcion;
  private  Map<Integer, Persona> personas;

  private static int contAct = 0;
  private int codLiga;

  public Liga() {
    crearLiga("", "");
  }

  public static int getContAct() {
    return contAct;
  }

  public static void setContAct(int contAct) {
    Liga.contAct = contAct;
  }

  public Liga(String nombre, String descripcion) {
    crearLiga(nombre, descripcion);
  }

  private void crearLiga(String nombre, String descripcion) {
    this.nombre = nombre;
    this.descripcion = descripcion;
    codLiga = ++contAct;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getDescripcion() {
    return descripcion;
  }

  public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
  }

  public Map<Integer, Persona> getPersonas() {
    return personas;
  }

  public Persona getPersona(int codPersona) {
    return personas.get(codPersona);
  }

  public void setPersonas(Map<Integer, Persona> personas) {
    this.personas = personas;
  }

  public void setPersona(Persona persona) {
    this.personas.put(persona.getCodigo(), persona);
  }

  public int getCodLiga() {
    return codLiga;
  }

}
