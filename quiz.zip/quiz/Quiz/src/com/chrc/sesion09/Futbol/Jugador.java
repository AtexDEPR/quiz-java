/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chrc.sesion09.Futbol;

/**
 *
 * @author campusLive Server
 */
public class Jugador extends Persona {

    public Jugador(String nombre, String apellido) {
        super(nombre, apellido);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Jugador{");
        sb.append(super.toString());
        sb.append('}');
        return sb.toString();
    }
    
}
