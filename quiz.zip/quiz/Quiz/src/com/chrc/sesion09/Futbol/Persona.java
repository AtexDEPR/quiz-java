/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chrc.sesion09.Futbol;

import java.util.List;

/**
 * Liga
 * liga
 * @author campusLive Server
 */
abstract public class Persona {
    private String nombre;
    private String apellido;
    private List<Liga> ligas;
    private static int contPersona = 0;
    private int codigo;

    public Persona() {
        crearPersona("", "");
    }
    
    public Persona(String nombre, String apellido) {
        crearPersona(nombre, apellido);
    }
    
    private void crearPersona(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
        ligas = null;
        codigo = ++contPersona;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public List<Liga> getLigas() {
        return ligas;
    }

    public void setLigas(List<Liga> ligas) {
        this.ligas = ligas;
    }
    
    public void setLiga(Liga liga) {
        this.ligas.add(liga);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("nombre=").append(nombre);
        sb.append(", apellido=").append(apellido);
        sb.append(", ligas=").append(ligas);
        return sb.toString();
    }

    public int getCodigo() {
        return codigo;
    }

}
